import speech_recognition as sr
import webbrowser
import pyttsx3
import musicLibrary
import requests
from openai import OpenAI
from gtts import gTTS
import pygame
import os
import browser

recognizer = sr.Recognizer()
engine = pyttsx3.init() 
newsapi = "36a14b4ea2bb4124a171475b71466fe8"

# def speak(text):
#     engine.say(text)
#     engine.runAndWait()

def speak(text):
    tts = gTTS(text)
    tts.save('temp.mp3') 

    # Initialize Pygame mixer
    pygame.mixer.init()

    # Load the MP3 file
    pygame.mixer.music.load('temp.mp3')

    # Play the MP3 file
    pygame.mixer.music.play()

    # Keep the program running until the music stops playing
    while pygame.mixer.music.get_busy():
        pygame.time.Clock().tick(10)
    
    pygame.mixer.music.unload()
    os.remove("temp.mp3") 

def aiProcess(command):
    client = OpenAI(api_key="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",
    )

    completion = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "system", "content": "You are a virtual assistant named jarvis skilled in general tasks like Alexa and Google Cloud. Give short responses please"},
        {"role": "user", "content": command}
    ]
    )

    return completion.choices[0].message.content

def processCommand(c):
    if c.lower().startswith("open"):
        brows = c.lower().split(" ")[1]
        if brows in browser.brow:  # Use the brow dictionary
            link1 = browser.brow[brows]
            webbrowser.open(link1)
            speak(f"Opening {brows}")
        else:
            speak(f"Sorry, I couldn't find {brows}.")
    elif c.lower().startswith("play"):
        song = c.lower().split(" ")[1]
        if song in musicLibrary.music:  # Use the music dictionary
            link = musicLibrary.music[song]
            webbrowser.open(link)
            speak(f"Playing {song}")
        else:
            speak(f"Sorry, I couldn't find the song {song}.")
    elif "news" in c.lower():
        r = requests.get(f"https://newsapi.org/v2/top-headlines?country=in&apiKey={newsapi}")
        if r.status_code == 200:
            data = r.json()
            articles = data.get('articles', [])
            if articles:
                for article in articles[:5]:  # Limit to 5 headlines
                    speak(article['title'])
            else:
                speak("No news articles found.")
        else:
            speak("Sorry, I couldn't fetch the news right now.")
    else:
        # speak("Sorry, I didn't understand the command.")
        output=aiProcess(c)
        speak(output)



# main code
if __name__ == "__main__":
    speak("Initializing Jarvis....")
    while True:
        r = sr.Recognizer()
        print("recognizing...")
        try:
            with sr.Microphone() as source:
                print("Listening...")
                audio = r.listen(source, timeout=2, phrase_time_limit=1)
            word = r.recognize_google(audio)
            if(word.lower() == "jarvis"):
                speak("Yes")
                # Listen for command
                with sr.Microphone() as source:
                    print("Jarvis Active...")
                    audio = r.listen(source)
                    command = r.recognize_google(audio)

                    processCommand(command)


        except Exception as e:
            print("Error; {0}".format(e))