brow={
    "google":"https://google.com",
    "youtube":"https://youtube.com",
}