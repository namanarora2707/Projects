from openai import OpenAI
 
# pip install openai 
# if you saved the key under a different environment variable name, you can do something like:
client = OpenAI(
  api_key="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",
)

completion = client.chat.completions.create(
  model="gpt-3.5-turbo",
  messages=[
    {"role": "system", "content": "You are a virtual assistant named archer skilled in general tasks like Alexa and Google Cloud"},
    {"role": "user", "content": "what is coding"}
  ]
)

print(completion.choices[0].message.content)